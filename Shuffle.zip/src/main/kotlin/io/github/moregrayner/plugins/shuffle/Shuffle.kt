package io.github.moregrayner.plugins.shuffle

import org.bukkit.Bukkit
import org.bukkit.Chunk
import org.bukkit.Location
import org.bukkit.World
import org.bukkit.block.data.BlockData
import org.bukkit.command.Command
import org.bukkit.command.CommandExecutor
import org.bukkit.command.CommandSender
import org.bukkit.plugin.java.JavaPlugin
import org.bukkit.scheduler.BukkitTask

class Shuffle : JavaPlugin() {
    private var shuffleTask: BukkitTask? = null
    private var activeWorld: World? = null
    private var chunkRadius: Int = 0
    private val chunkDataMap = mutableMapOf<ChunkPos, ChunkData>()

    override fun onEnable() {
        getCommand("shuffle")?.setExecutor(ShuffleCommand())
    }

    override fun onDisable() {
        shuffleTask?.cancel()
    }

    inner class ShuffleCommand : CommandExecutor {
        override fun onCommand(
            sender: CommandSender,
            command: Command,
            label: String,
            args: Array<out String>
        ): Boolean {
            if (args.isEmpty()) {
                sender.sendMessage("/shuffle start <반경> <주기(분)> 또는 /shuffle stop")
                return true
            }

            when (args[0].lowercase()) {
                "start" -> {
                    if (args.size < 3) {
                        sender.sendMessage("/shuffle start <반경> <주기(분)>")
                        return true
                    }

                    val radius = args[1].toIntOrNull()
                    val interval = args[2].toIntOrNull()

                    if (radius == null || interval == null || radius <= 0 || interval <= 0) {
                        sender.sendMessage("§c반경과 주기는 양수여야 합니다.")
                        return true
                    }

                    if (shuffleTask != null) {
                        sender.sendMessage("§c이미 셔플이 진행 중입니다. 먼저 /shuffle stop을 사용하세요.")
                        return true
                    }

                    startShuffle(server.worlds.first(), radius, interval)
                    sender.sendMessage("§a청크 셔플이 시작되었습니다. (반경: $radius, 주기: ${interval}분)")
                }
                "stop" -> {
                    if (shuffleTask == null) {
                        sender.sendMessage("§c진행 중인 셔플이 없습니다.")
                        return true
                    }

                    stopShuffle()
                    sender.sendMessage("§a청크 셔플이 중지되었습니다.")
                }
                else -> {
                    sender.sendMessage("§c알 수 없는 명령어입니다. start 또는 stop을 사용하세요.")
                }
            }

            return true
        }
    }

    private fun startShuffle(world: World, radius: Int, intervalMinutes: Int) {
        activeWorld = world
        chunkRadius = radius
        chunkDataMap.clear()

        for (x in -radius..radius) {
            for (z in -radius..radius) {
                val chunk = world.getChunkAt(x, z)
                chunk.load()
                val pos = ChunkPos(x, z)
                chunkDataMap[pos] = ChunkData.fromChunk(chunk)
            }
        }

        val borderSize = (radius * 16 * 2).toDouble()
        val worldBorder = world.worldBorder
        worldBorder.center = Location(world, 0.0, 64.0, 0.0)
        worldBorder.size = borderSize
        worldBorder.warningDistance = 5
        worldBorder.damageAmount = 0.2

        val intervalTicks = intervalMinutes * 1200L
        shuffleTask = Bukkit.getScheduler().runTaskTimer(this, Runnable {
            performShuffle()
        }, intervalTicks, intervalTicks)
    }

    private fun stopShuffle() {
        shuffleTask?.cancel()
        shuffleTask = null

        activeWorld?.worldBorder?.size = 60000000.0

        activeWorld = null
        chunkDataMap.clear()
    }

    private fun performShuffle() {
        val world = activeWorld ?: return
        val positions = chunkDataMap.keys.toMutableList()

        if (positions.size < 2) return

        positions.shuffle()

        val pairs = mutableListOf<Pair<ChunkPos, ChunkPos>>()
        for (i in 0 until positions.size - 1 step 2) {
            pairs.add(Pair(positions[i], positions[i + 1]))
        }

        val swapData = mutableListOf<Triple<ChunkPos, ChunkPos, Pair<ChunkData, ChunkData>>>()
        for ((pos1, pos2) in pairs) {
            val data1 = chunkDataMap[pos1] ?: continue
            val data2 = chunkDataMap[pos2] ?: continue
            swapData.add(Triple(pos1, pos2, Pair(data1, data2)))
        }

        Bukkit.getScheduler().runTask(this, Runnable {
            for ((pos1, pos2, data) in swapData) {
                val chunk1 = world.getChunkAt(pos1.x, pos1.z)
                val chunk2 = world.getChunkAt(pos2.x, pos2.z)

                data.second.applyToChunk(chunk1)
                data.first.applyToChunk(chunk2)

                chunkDataMap[pos1] = data.second
                chunkDataMap[pos2] = data.first
            }

            Bukkit.getScheduler().runTaskLater(this, Runnable {
                teleportPlayersInAffectedChunks(world, swapData.flatMap { listOf(it.first, it.second) })
            }, 1L)
        })
    }

    private fun teleportPlayersInAffectedChunks(world: World, affectedChunks: List<ChunkPos>) {
        for (player in world.players) {
            val playerChunk = player.location.chunk
            val playerPos = ChunkPos(playerChunk.x, playerChunk.z)

            if (playerPos in affectedChunks) {
                val highestY = world.getHighestBlockYAt(player.location)
                val safeLoc = Location(world, player.location.x, highestY.toDouble() + 1, player.location.z)
                player.teleport(safeLoc)
                player.sendMessage("§e청크가 셔플되었습니다!")
            }
        }
    }

    data class ChunkPos(val x: Int, val z: Int)

    data class ChunkData(
        val blockData: Array<Array<Array<BlockData>>>
    ) {
        companion object {
            fun fromChunk(chunk: Chunk): ChunkData {
                val data = Array(16) { x ->
                    Array(chunk.world.maxHeight) { y ->
                        Array(16) { z ->
                            chunk.getBlock(x, y, z).blockData.clone()
                        }
                    }
                }
                return ChunkData(data)
            }
        }

        fun applyToChunk(chunk: Chunk) {
            for (x in 0 until 16) {
                for (y in 0 until blockData[0].size) {
                    for (z in 0 until 16) {
                        val block = chunk.getBlock(x, y, z)
                        blockData[x][y][z].let {
                            block.blockData = it
                        }
                    }
                }
            }
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            other as ChunkData
            return blockData.contentDeepEquals(other.blockData)
        }

        override fun hashCode(): Int {
            return blockData.contentDeepHashCode()
        }
    }
}